# FlipIQ CSM Dashboard

AI-powered coaching engine for Acquisition Associates. Built for Ramy (CSM) to track, coach, and manage 40+ AAs across 7 organizations.

## Quick Start (Works immediately with mock data)

```bash
npm install
npm run dev
```

The dashboard runs with mock data out of the box. No Supabase required to see and test the UI.

## Connect Supabase (Live Data)

1. Create a project at [supabase.com](https://supabase.com)
2. Go to SQL Editor and run `supabase/schema.sql` (creates all tables, views, seeds orgs + 61 events)
3. Copy your project URL and anon key from Settings > API
4. Create `.env` file (copy from `.env.example`):

```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIs...
```

5. Restart the dev server. The yellow "Mock data" banner disappears when connected.

## Project Structure

```
flipiq-csm-dashboard/
  index.html              - Entry HTML with DM Sans font
  vite.config.js          - Vite config (React plugin)
  package.json            - Dependencies
  .env.example            - Environment variable template
  src/
    main.jsx              - React entry point
    App.jsx               - Complete dashboard (V9 prototype)
    lib/
      supabase.js         - Supabase client + all data functions
  supabase/
    schema.sql            - Complete DB schema (10 tables, 2 views, 61 events seeded)
```

## Architecture

```
COMMAND DB ──> Nate's Lambda (5:00 AM) ──> Supabase
                                              |
Claude (5:10 AM) reads ──────────────────────>|
Claude writes emails + health scores ────────>|
                                              |
React Dashboard reads <───────────────────────|
Ramy reviews + forwards + checks off tasks ──>|
```

## Tabs

- **Overview** - KPI, task list with check-off, gamification
- **Leaderboard** - Full My Stats with date ranges
- **Heat Map** - 61 events, 7 categories, 3-Track expandable
- **Emails** - Coaching email generation and preview
- **Email Logic** - Complete 34-row trigger sequence

## Deploy to Replit from GitHub

1. Push this repo to GitHub
2. In Replit: Create new Repl > Import from GitHub
3. Select the repo
4. Replit auto-detects Vite/React
5. Add Supabase secrets in Replit Secrets tab
6. Click Run

## Tech Spec

See `FlipIQ_Deal_Dashboard_Engine_V3_TechSpec.docx` for the complete technical specification.
