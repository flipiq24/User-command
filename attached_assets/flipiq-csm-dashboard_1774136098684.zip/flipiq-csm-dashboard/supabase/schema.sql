-- =====================================================
-- FLIPIQ CSM DASHBOARD - SUPABASE SCHEMA
-- Run in Supabase SQL Editor (supabase.com > SQL Editor)
-- =====================================================

CREATE TABLE organizations (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  domain TEXT,
  principal TEXT,
  am_name TEXT NOT NULL,
  am_email TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT,
  org_id INTEGER REFERENCES organizations(id),
  phase INTEGER NOT NULL DEFAULT 1 CHECK (phase IN (1, 2, 3)),
  day_number INTEGER NOT NULL DEFAULT 1,
  start_date DATE NOT NULL DEFAULT CURRENT_DATE,
  health TEXT NOT NULL DEFAULT 'red' CHECK (health IN ('red', 'orange', 'yellow', 'green')),
  priority_score INTEGER NOT NULL DEFAULT 1 CHECK (priority_score BETWEEN 1 AND 4),
  goals_calls_per_day INTEGER DEFAULT 30,
  goals_offers_per_day INTEGER DEFAULT 3,
  goals_contacts_per_day INTEGER DEFAULT 50,
  discussion_agenda TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE daily_stats (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  stat_date DATE NOT NULL DEFAULT CURRENT_DATE,
  texts INTEGER DEFAULT 0,
  emails INTEGER DEFAULT 0,
  calls INTEGER DEFAULT 0,
  calls_connected INTEGER DEFAULT 0,
  new_relationships INTEGER DEFAULT 0,
  upgraded INTEGER DEFAULT 0,
  priority_high INTEGER DEFAULT 0,
  priority_warm INTEGER DEFAULT 0,
  opened_new INTEGER DEFAULT 0,
  reopened INTEGER DEFAULT 0,
  offers_sent INTEGER DEFAULT 0,
  offers_terms INTEGER DEFAULT 0,
  offers_contracts INTEGER DEFAULT 0,
  negotiations INTEGER DEFAULT 0,
  accepted INTEGER DEFAULT 0,
  acquired INTEGER DEFAULT 0,
  total_minutes INTEGER DEFAULT 0,
  piq_minutes INTEGER DEFAULT 0,
  comps_minutes INTEGER DEFAULT 0,
  ia_minutes INTEGER DEFAULT 0,
  offer_minutes INTEGER DEFAULT 0,
  agents_minutes INTEGER DEFAULT 0,
  source_mls INTEGER DEFAULT 0,
  source_direct_mail INTEGER DEFAULT 0,
  source_cold_call INTEGER DEFAULT 0,
  source_referral INTEGER DEFAULT 0,
  checkin_completed BOOLEAN DEFAULT false,
  checkin_time TIMESTAMPTZ,
  blocker_text TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, stat_date)
);

CREATE TABLE events (
  id SERIAL PRIMARY KEY,
  event_number INTEGER NOT NULL,
  category TEXT NOT NULL,
  action TEXT NOT NULL,
  phase_number INTEGER,
  priority_level TEXT,
  trigger_needed BOOLEAN DEFAULT false
);

CREATE TABLE event_categories (
  id SERIAL PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  display_order INTEGER NOT NULL
);

INSERT INTO event_categories (slug, name, display_order) VALUES
  ('plan', 'Today''s Plan', 1),
  ('find', 'Find Deals', 2),
  ('comm', 'Communication', 3),
  ('prop', 'Property Actions', 4),
  ('analysis', 'Analysis', 5),
  ('offers', 'Offers', 6),
  ('tools', 'Tools & Reporting', 7);

CREATE TABLE user_events (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  event_id INTEGER REFERENCES events(id) ON DELETE CASCADE,
  first_used TIMESTAMPTZ,
  use_count INTEGER DEFAULT 0,
  last_used TIMESTAMPTZ,
  status TEXT DEFAULT 'missing' CHECK (status IN ('missing', 'gap', 'cooling', 'active')),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, event_id)
);

CREATE TABLE user_category_scores (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  category_slug TEXT REFERENCES event_categories(slug),
  score INTEGER DEFAULT 0 CHECK (score BETWEEN 0 AND 3),
  active_count INTEGER DEFAULT 0,
  missing_count INTEGER DEFAULT 0,
  total_count INTEGER DEFAULT 0,
  total_uses INTEGER DEFAULT 0,
  first_any TIMESTAMPTZ,
  last_any TIMESTAMPTZ,
  computed_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, category_slug)
);

CREATE TABLE coaching_emails (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  email_date DATE NOT NULL DEFAULT CURRENT_DATE,
  to_name TEXT NOT NULL,
  to_email TEXT,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  is_escalation BOOLEAN DEFAULT false,
  escalation_to TEXT,
  video_included TEXT,
  root_cause TEXT,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'reviewed', 'forwarded', 'skipped')),
  forwarded_at TIMESTAMPTZ,
  forwarded_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE email_history (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  emails_sent INTEGER DEFAULT 0,
  last_email_date DATE,
  last_response_date DATE,
  has_responded BOOLEAN DEFAULT false,
  escalated_to_am BOOLEAN DEFAULT false,
  escalated_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)
);

CREATE TABLE task_completions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  task_date DATE NOT NULL DEFAULT CURRENT_DATE,
  action_type TEXT NOT NULL CHECK (action_type IN ('call', 'text', 'email', 'notify_am', 'walkthrough', 'other')),
  notes TEXT,
  completed_at TIMESTAMPTZ DEFAULT NOW(),
  completed_by TEXT DEFAULT 'Ramy'
);

CREATE TABLE user_gaps (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  gap_text TEXT NOT NULL,
  detected_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE trigger_log (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  trigger_type TEXT NOT NULL,
  trigger_condition TEXT NOT NULL,
  action_taken TEXT,
  fired_at TIMESTAMPTZ DEFAULT NOW()
);

-- INDEXES
CREATE INDEX idx_daily_stats_user_date ON daily_stats(user_id, stat_date);
CREATE INDEX idx_user_events_user ON user_events(user_id);
CREATE INDEX idx_coaching_emails_user_date ON coaching_emails(user_id, email_date);
CREATE INDEX idx_task_completions_date ON task_completions(task_date);
CREATE INDEX idx_users_org ON users(org_id);
CREATE INDEX idx_users_health ON users(health);
CREATE INDEX idx_users_phase ON users(phase);

-- RLS
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE coaching_emails ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_completions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_gaps ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE trigger_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "read_all" ON organizations FOR SELECT USING (true);
CREATE POLICY "read_all" ON users FOR SELECT USING (true);
CREATE POLICY "read_all" ON daily_stats FOR SELECT USING (true);
CREATE POLICY "read_all" ON user_events FOR SELECT USING (true);
CREATE POLICY "read_all" ON coaching_emails FOR SELECT USING (true);
CREATE POLICY "read_all" ON task_completions FOR SELECT USING (true);
CREATE POLICY "read_all" ON user_gaps FOR SELECT USING (true);
CREATE POLICY "read_all" ON email_history FOR SELECT USING (true);
CREATE POLICY "read_all" ON trigger_log FOR SELECT USING (true);

CREATE POLICY "write_all" ON daily_stats FOR ALL USING (true);
CREATE POLICY "write_all" ON user_events FOR ALL USING (true);
CREATE POLICY "write_all" ON coaching_emails FOR ALL USING (true);
CREATE POLICY "write_all" ON task_completions FOR ALL USING (true);
CREATE POLICY "write_all" ON user_gaps FOR ALL USING (true);
CREATE POLICY "write_all" ON email_history FOR ALL USING (true);
CREATE POLICY "write_all" ON trigger_log FOR ALL USING (true);

-- VIEW: Dashboard (one row per user with today + yesterday stats)
CREATE VIEW user_dashboard AS
SELECT
  u.id, u.name, u.email, u.phase, u.day_number, u.health, u.priority_score,
  u.goals_calls_per_day, u.goals_offers_per_day, u.goals_contacts_per_day,
  u.discussion_agenda,
  o.name AS org_name, o.am_name, o.am_email,
  ds.texts, ds.emails, ds.calls, ds.calls_connected,
  ds.new_relationships, ds.upgraded, ds.opened_new, ds.reopened,
  ds.offers_sent, ds.negotiations, ds.accepted, ds.acquired,
  ds.total_minutes, ds.checkin_completed,
  yd.texts AS y_texts, yd.emails AS y_emails, yd.calls AS y_calls,
  yd.offers_sent AS y_offers, yd.opened_new AS y_opened,
  eh.emails_sent, eh.has_responded, eh.escalated_to_am
FROM users u
JOIN organizations o ON u.org_id = o.id
LEFT JOIN daily_stats ds ON u.id = ds.user_id AND ds.stat_date = CURRENT_DATE
LEFT JOIN daily_stats yd ON u.id = yd.user_id AND yd.stat_date = CURRENT_DATE - 1
LEFT JOIN email_history eh ON u.id = eh.user_id
WHERE u.active = true;

-- VIEW: Leaderboard
CREATE VIEW leaderboard AS
SELECT
  u.id, u.name, u.health, u.phase, u.day_number,
  o.name AS org_name,
  COALESCE(SUM(ds.texts), 0) AS total_texts,
  COALESCE(SUM(ds.emails), 0) AS total_emails,
  COALESCE(SUM(ds.calls), 0) AS total_calls,
  COALESCE(SUM(ds.calls_connected), 0) AS total_calls_connected,
  COALESCE(SUM(ds.new_relationships), 0) AS total_new_rel,
  COALESCE(SUM(ds.upgraded), 0) AS total_upgraded,
  COALESCE(SUM(ds.opened_new), 0) AS total_opened,
  COALESCE(SUM(ds.reopened), 0) AS total_reopened,
  COALESCE(SUM(ds.offers_sent), 0) AS total_offers,
  COALESCE(SUM(ds.negotiations), 0) AS total_negot,
  COALESCE(SUM(ds.accepted), 0) AS total_accepted,
  COALESCE(SUM(ds.acquired), 0) AS total_acquired,
  COALESCE(SUM(ds.total_minutes), 0) AS total_minutes
FROM users u
JOIN organizations o ON u.org_id = o.id
LEFT JOIN daily_stats ds ON u.id = ds.user_id
WHERE u.active = true
GROUP BY u.id, u.name, u.health, u.phase, u.day_number, o.name;

-- HELPER: increment email count for 3-strike tracking
CREATE OR REPLACE FUNCTION increment_email_count(p_user_id INTEGER)
RETURNS VOID AS $$
BEGIN
  INSERT INTO email_history (user_id, emails_sent, last_email_date)
  VALUES (p_user_id, 1, CURRENT_DATE)
  ON CONFLICT (user_id)
  DO UPDATE SET
    emails_sent = email_history.emails_sent + 1,
    last_email_date = CURRENT_DATE,
    updated_at = NOW();
END;
$$ LANGUAGE plpgsql;

-- SEED: Organizations
INSERT INTO organizations (name, domain, principal, am_name, am_email) VALUES
  ('Coko Homes', 'cokohomes.com', 'Jonathan Carbajal', 'Gregory Patterson', 'gregory@cokohomes.com'),
  ('Hegemark Property Group', 'hegemarkpropertygroup.co', 'Eric Lau', 'Jeffrey Kuo', 'jeffrey@hegemarkpropertygroup.co'),
  ('TD Realty', 'tdrealty.net', 'Owner', 'Matt Carmean', 'matt@tdrealty.net'),
  ('STJ Investments', 'stjinvestmentsllc.pro', 'Sergio Tafolla', 'Andruw Tafolla', 'andruw@stjinvestmentsllc.pro'),
  ('Fair Close', 'fairclose.net', 'Owner', 'Tony Fletcher', 'tony@fairclose.net');

-- SEED: 61 Events
INSERT INTO events (event_number, category, action, phase_number, priority_level, trigger_needed) VALUES
  (1,'plan','iQ Check-In',1,'Critical',true),(2,'plan','Report blockers',1,'Standard',false),
  (3,'plan','Open Deal Review',1,'Critical',true),(4,'plan','Review Critical Calls',1,'Critical',true),
  (5,'plan','No Properties in priorities',1,'Critical',true),(6,'plan','Review High Priority',1,'Critical',true),
  (7,'plan','Review Medium Priority',1,'Critical',true),(8,'plan','Review Low Priority',1,'Critical',true),
  (9,'plan','Process New Deals',1,'Critical',true),(10,'plan','Open Daily Outreach',1,'Critical',true),
  (11,'plan','Call from Outreach list',1,'Critical',true),(12,'plan','Open My Active Deals',1,'Critical',true),
  (13,'find','Open MLS Hot Deals',2,'Critical',false),(14,'find','Filter MLS Hot Deals',2,'Critical',false),
  (15,'find','Open MLS Search',2,'Critical',false),(16,'find','Apply MLS Search filters',2,'Standard',false),
  (17,'find','Save a filter',2,'Standard',false),(18,'find','Open Agent Search',3,'Critical',false),
  (19,'find','Search/filter agents',3,'Critical',true),(20,'find','Open Agent Profile',3,'Critical',true),
  (21,'find','Open Campaigns',2,'Critical',true),(22,'find','Select a campaign',2,'Critical',true),
  (23,'find','Send campaign',2,'Critical',true),(24,'comm','Call agent (single)',1,'Critical',true),
  (25,'comm','Text agent (single)',1,'Critical',true),(26,'comm','Email agent (single)',1,'Critical',true),
  (27,'comm','Text Voicemail',1,'Standard',false),(28,'comm','AI Connect',1,'Critical',true),
  (29,'comm','Bulk Call',2,'Critical',true),(30,'comm','Bulk Text',2,'Critical',true),
  (31,'comm','Bulk Email',2,'Critical',true),(32,'comm','Bulk Text Voicemail',2,'Standard',false),
  (33,'comm','Bulk AI Connect',2,'Standard',false),(34,'prop','Add a Note',1,'Standard',true),
  (35,'prop','View Tax Data',1,'Critical',true),(36,'prop','View Activity history',1,'Critical',true),
  (37,'prop','Create Reminder',1,'Critical',true),(38,'prop','View AI Report',1,'Critical',true),
  (39,'prop','Property Check-In',1,'Critical',false),(40,'prop','Change Offer Status',1,'Critical',true),
  (41,'prop','Change Priority',1,'Critical',true),(42,'prop','Add a Property',1,'Critical',true),
  (43,'prop','Set To Do',1,'Critical',true),(44,'prop','Add to Favorites',1,'Standard',false),
  (45,'prop','Filter by Agent Deals',1,'Critical',true),(46,'prop','Set Follow-Up',1,'Critical',true),
  (47,'analysis','Open PIQ Detail',1,'Critical',true),(48,'analysis','View Comps Map',1,'Critical',true),
  (49,'analysis','View Comps Matrix',1,'Critical',true),(50,'analysis','View Comps List',1,'Critical',true),
  (51,'analysis','Run Investment Analysis',1,'Critical',true),(52,'offers','Send Offer Terms',1,'Critical',true),
  (53,'offers','Submit Contract',1,'Critical',true),(54,'offers','Update Negotiation',1,'Critical',true),
  (55,'offers','Review offer count vs goal',1,'Critical',true),(56,'tools','Open My Stats',1,'Standard',true),
  (57,'tools','Open DispoPro',1,'Standard',true),(58,'tools','Open Quick Links',1,'Standard',false),
  (59,'tools','Login',1,'Critical',true),(60,'tools','Script Practice',1,'Standard',false),
  (61,'tools','Post-call feedback',1,'Standard',false),(62,'tools','End-of-Day Stats',1,'Standard',true);
